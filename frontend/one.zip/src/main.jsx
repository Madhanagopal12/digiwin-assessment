import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import About from "./components/About.jsx";
import Header from "./components/Header.jsx";
import Hero from "./components/Hero.jsx";
import Objectives from "./components/Objectives.jsx";
import Projects from "./components/Projects.jsx";
import Services from "./components/Services.jsx";
import "./index.css";
import ClientTestimonial from "./components/ClientTestimonials.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Header />
    <Hero nextId="about" />
    <About />
    <Objectives />
    <Services />
    <Projects />
    <ClientTestimonial />
  </StrictMode>,
);
