function About() {
  return (
    // relative + z-10: paints above the pinned hero while it slides up over it.
    // min-h-screen: fully covers the hero. rounded-t: the "card" top edge
    // (remove it if your border-radius-left/right classes already round the corners).
    <div
      id="about"
      className="relative z-10 min-h-screen m-auto border-radius-right border-radius-left rounded-t-[40px] bg-white"
    >
      <div className="flex flex-col items-center justify-center pt-16">
        <div>
          <svg viewBox="0 0 254.79 254.79" className="h-auto w-24">
            <g>
              <g></g>
              <g>
                <path
                  className="icon"
                  fill="#aaa0a0"
                  d="M95.12,82.53h-12.71c-3.17,0-5.75,2.58-5.75,5.75v78.24c0,3.17,2.58,5.75,5.75,5.75h9.07c3.17,0,5.75-2.58,5.75-5.75v-47.82c0-1.25.72-2.33,1.88-2.81,1.16-.48,2.43-.23,3.31.66l20.84,20.84c2.24,2.24,5.89,2.24,8.13,0l10.48-10.48-42.69-42.7c-1.08-1.08-2.53-1.68-4.06-1.68Z"
                ></path>
                <path
                  className="icon"
                  fill="#aaa0a0"
                  d="M172.38,82.53h-12.71c-1.54,0-2.98.6-4.06,1.68l-25.02,25.03,14.55,14.55,7.24-7.24c.59-.59,1.35-.9,2.13-.9.4,0,.8.08,1.18.24,1.16.48,1.88,1.56,1.88,2.81v47.82c0,3.17,2.58,5.75,5.75,5.75h9.07c3.17,0,5.75-2.58,5.75-5.75v-78.24c0-3.17-2.58-5.75-5.75-5.75Z"
                ></path>
              </g>
            </g>
          </svg>
        </div>
        <p className="text-center text-3xl/loose about-width mt-4 mb-24 font-inter ">
          Main dans la main avec nos clients, notre agence réalise des projets
          marketing puissants et met en œuvre des stratégies publicitaires
          performantes. Tout cela grâce à une équipe dynamique et riche d’une
          expérience de 25+ ans.
        </p>
      </div>
      <div className="mb-10">
        <p className="text-left text-5xl/relaxed pl-20 ">Vos objectifs,</p>
        <p className="text-left text-5xl pl-20 ">notre mission!</p>
      </div>
      <div className="w-2/4 ml-auto pb-16">
        <p className="text-2xl font-inter">
          Nous comprenons vos défis et apportons des solutions complètes,
          intelligentes, digitales et éprouvées.
        </p>
        <h2 className="font-inter text-2xl">
          Pourquoi notre marketing digital ?
        </h2>
      </div>
    </div>
  );
}

export default About;
