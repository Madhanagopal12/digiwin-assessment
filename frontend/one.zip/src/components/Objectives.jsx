import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { NetworkIcon, RadioIcon } from "lucide-react";
import horizontalLoop from "./HorizontalLoop";

gsap.registerPlugin(ScrollTrigger);

// Replace with your real content (Icon can be any lucide-react icon).
const ITEMS = [
  {
    Icon: RadioIcon,
    iconText: "visibilité",
    title: "Plus de visibilité",
    description:
      "Image de marque forte, notoriété renforcée & une longueur d'avance sur vos concurrents.",
  },
  {
    Icon: NetworkIcon,
    iconText: "visibilité",
    title: "Plus de visibilité",
    description:
      "Image de marque forte, notoriété renforcée & une longueur d'avance sur vos concurrents.",
  },
  {
    Icon: NetworkIcon,
    iconText: "visibilité",
    title: "Plus de visibilité",
    description:
      "Image de marque forte, notoriété renforcée & une longueur d'avance sur vos concurrents.",
  },
  {
    Icon: NetworkIcon,
    iconText: "visibilité",
    title: "Plus de visibilité",
    description:
      "Image de marque forte, notoriété renforcée & une longueur d'avance sur vos concurrents.",
  },
];

/*
  Pinned section: while the user scrolls, the row of cards travels
  horizontally in a seamless loop (scrubbed to the scrollbar).
  With reduced motion nothing is pinned; the cards are simply stacked.
*/
export default function Objectives({
  items = ITEMS,
  scrollDistance = "+=200%", // how long the section stays pinned
  debug = false,
}) {
  const sectionRef = useRef(null);
  const railRef = useRef(null);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const ctx = gsap.context(() => {}, sectionRef);
    let cancelled = false;

    // Wait for fonts: the loop measures each card's width.
    document.fonts.ready.then(() => {
      if (cancelled) return;

      ctx.add(() => {
        const cards = gsap.utils.toArray(railRef.current.children);
        const last = cards[cards.length - 1];

        const loop = horizontalLoop(cards, {
          repeat: 1,
          paused: true,
          paddingRight: parseFloat(getComputedStyle(last).marginRight) || 0,
        });

        ScrollTrigger.create({
          trigger: sectionRef.current,
          start: "top top",
          end: scrollDistance,
          pin: true,
          animation: loop,
          scrub: 0.5,
          invalidateOnRefresh: true,
          markers: debug,
        });
      });
    });

    return () => {
      cancelled = true;
      ctx.revert();
    };
  }, [scrollDistance, debug]);

  return (
    <section
      id="objectives"
      ref={sectionRef}
      aria-label="Témoignages"
      className="relative flex h-screen w-full items-center overflow-hidden bg-white font-['Outfit',sans-serif] motion-reduce:h-auto motion-reduce:py-24"
    >
      <div
        ref={railRef}
        className="flex motion-reduce:flex-col motion-reduce:gap-10 motion-reduce:px-6 p-5  "
      >
        {items.map((item, i) => (
          <TestimonialWrapper key={i} {...item} />
        ))}
      </div>
    </section>
  );
}

function TestimonialWrapper({ Icon, iconText, title, description }) {
  return (
    <article className="mr-10 w-3/5 max-w-[1351px] h-[443px] max-h-[443px] rounded-2xl shrink-0 bg-[#F7F9FB] p-12 motion-reduce:mr-0 motion-reduce:w-full">
      <div className="flex justify-between pb-10">
        <Icon className="text-blue-600" aria-hidden="true" />
        <span>
          <span className="text-blue-600">#</span>
          {iconText}
        </span>
      </div>
      <h2 className="mb-[120px] text-4xl">{title}</h2>
      <p className="text-2xl">{description}</p>
    </article>
  );
}
