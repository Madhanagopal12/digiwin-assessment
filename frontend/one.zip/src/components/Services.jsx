import ServiceCards from "./ServiceCards";

function Services() {
  return (
    <section className=" bg-[#182533] ">
      <div className="container service-width ">
        <div className=" py-36">
          <div className="mb-16">
            <span className="text-7xl/relaxed font-medium text-white block">
              A la carte ou
            </span>
            <span className="text-7xl font-medium text-white block">
              full-service
            </span>
          </div>
          <div className="flex justify-between">
            <h2 className="text-white w-2/5 text-2xl ">Services d’agence</h2>
            <p className="w-3/6 text-white text-2xl">
              Notre équipe in-house maitrise l’ensemble du spectre du marketing
              digital. De la stratégie à la création jusqu'aux campagnes
              sophistiquées.
            </p>
          </div>
        </div>
      </div>
      <ServiceCards />
    </section>
  );
}

export default Services;
