import { useState } from "react";
import { ArrowLeftIcon, ArrowRightIcon, ArrowUpRightIcon } from "lucide-react";

// One entry per project. Use `image` or `video` for the big media on the left.
// The two small images at the bottom use default paths: replace the files
// (or the paths) with your own.
const PROJECTS = [
  {
    title: "Restaurant le Jardin",
    description:
      "Sobre, élégant, raffiné: ces adjectifs nous servent de fil rouge pour tous les projets digitaux et graphiques du restaurant Le Jardin.",
    video: "src/assets/video/project-lampertz.mp4",
    thumbA: "src/assets/images/project-1-thumb-1.jpg",
    thumbB: "src/assets/images/project-1-thumb-3.png",
    href: "#",
  },
  {
    title: "Lampertz Stone Designer",
    description:
      "Nous avons livré un site de présentation attrayant à ce spécialiste de la pierre naturelle au Luxembourg.",
    video: "src/assets/video/project-lampertz.mp4",
    thumbA: "src/assets/images/project-lampertz-mobile.jpg",
    thumbB: "src/assets/images/project-lampertz-logo.png",
    href: "#",
  },
];

function ProjectCard({ project, onPrev, onNext }) {
  const {
    title,
    description,
    image,
    video,
    thumbA,
    thumbB,
    href = "#",
  } = project;

  return (
    <article className="grid grid-cols-2 gap-8 rounded-2xl bg-[#F7F9FB] p-7 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:gap-10">
      {/* Main media */}
      <div className="h-80 overflow-hidden rounded-2xl lg:h-[485px]">
        {video ? (
          <video
            key={video}
            className="h-full w-full object-cover"
            src={video}
            autoPlay
            muted
            loop
            playsInline
          />
        ) : (
          <img src={image} alt="" className="h-full w-full object-cover" />
        )}
      </div>

      {/* Text, controls and thumbnails */}
      <div className="flex flex-col justify-between gap-10">
        <div>
          <div className="flex items-start justify-between gap-6">
            <h3 className="text-3xl font-medium">{title}</h3>
            <div className="flex shrink-0 items-center gap-4">
              <button
                type="button"
                onClick={onPrev}
                aria-label="Projet précédent"
                className="rounded-full p-1 transition-opacity hover:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#355170]"
              >
                <ArrowLeftIcon />
              </button>
              <button
                type="button"
                onClick={onNext}
                aria-label="Projet suivant"
                className="rounded-full p-1 transition-opacity hover:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#355170]"
              >
                <ArrowRightIcon />
              </button>
            </div>
          </div>

          <p className="mt-10 max-w-[300px] text-xl leading-relaxed">
            {description}
          </p>

          <a
            href={href}
            className="mt-6 inline-flex items-center gap-3 rounded-lg border border-[#355170] bg-white px-5 py-3 text-sm transition-colors hover:bg-[#355170] hover:text-white"
          >
            Voir le projet
            <ArrowUpRightIcon size={16} aria-hidden="true" />
          </a>
        </div>

        {/* Two small images */}
        <div className="grid grid-cols-2 gap-6 lg:gap-8">
          <div className="h-40 overflow-hidden rounded-xl">
            <img src={thumbA} alt="" className="h-full w-full object-cover" />
          </div>
          <div className="flex h-40 items-center justify-center overflow-hidden rounded-xl bg-white p-6">
            <img src={thumbB} alt="" className="h-full w-full object-contain" />
          </div>
        </div>
      </div>
    </article>
  );
}

function Projects({ projects = PROJECTS }) {
  const [index, setIndex] = useState(0);
  const count = projects.length;

  const prev = () => setIndex((i) => (i - 1 + count) % count);
  const next = () => setIndex((i) => (i + 1) % count);

  return (
    <section className="bg-white pb-24 pt-36">
      <div className="container ">
        <div className="mb-12 flex items-end justify-between">
          <div>
            <span className="block text-7xl/relaxed">
              Les créations fraîches
            </span>
            <span className="block text-7xl/relaxed">de la team</span>
            <h2 className="mt-14 text-2xl text-gray-400">
              Projects d’agence récents
            </h2>
          </div>
          <a href="#" className="text-[22px] underline">
            Découvrir tous les projets
          </a>
        </div>
      </div>

      <div className="container" aria-live="polite">
        <ProjectCard project={projects[index]} onPrev={prev} onNext={next} />
      </div>
    </section>
  );
}

export default Projects;
