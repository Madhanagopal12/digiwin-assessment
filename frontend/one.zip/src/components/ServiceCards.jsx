import { ArrowRightIcon } from "lucide-react";

// One entry per card. Add or edit entries here.
const SERVICES = [
  {
    label: "Strategy",
    title: "Stratégies marketing qui fonctionnent efficacement.",
    items: ["Stratégie marketing", "Stratégie marketing"],
    image: "src/assets/images/service-image-1.jpg",
  },
  {
    label: "Creation",
    title: "Titre du service 2.",
    items: ["Point clé 1", "Point clé 2"],
    image: "src/assets/images/service-image-2.jpg",
  },
  {
    label: "Marketing",
    title: "Campagnes intelligentes aux résultats mesurables.",
    items: ["Point clé 1", "Point clé 2"],
    image: "src/assets/images/service-image-3.jpg",
  },
  {
    label: "Applications",
    title:
      "Outils digitaux qui révolutionnent votre quotidien et vos processus.",
    items: ["Point clé 1", "Point clé 2"],
    image: "src/assets/images/service-image-4.jpg",
  },
];

/* A single reusable card: text panel on one side, image on the other.
   `number` shows as the small "(01)" before the label.
   `reverse` puts the image on the left. */
export function ServiceCard({
  number,
  label,
  title,
  items = [],
  image,
  imageAlt = "",
  reverse = false,
}) {
  return (
    <article
      className={[
        "flex w-full flex-col overflow-hidden rounded-2xl border-2 border-[#355170] bg-[#182533] lg:flex-row",
        reverse ? "lg:flex-row-reverse" : "",
      ].join(" ")}
    >
      {/* Text panel */}
      <div
        className="relative px-8 py-10 sm:px-12 lg:w-1/2
          before:absolute before:left-0 before:top-0 before:z-0 before:h-full before:w-full before:content-['']
          before:bg-[radial-gradient(circle_at_0%_100%,_#293D53_0%,_#182533_70%,_#182533_100%)]"
      >
        <div className="relative z-10">
          <div className="flex items-baseline gap-2 text-2xl text-white">
            {number && (
              <span className="text-lg font-light text-[#00a8e0]">
                ({number})
              </span>
            )}
            <span className="servicecard-service font-medium">{label}</span>
          </div>
          <h3 className="mt-10 text-3xl font-semibold text-white">{title}</h3>

          {items.length > 0 && (
            <ul className="mt-14 flex flex-col gap-8">
              {items.map((item, i) => (
                <li key={i} className="flex items-center gap-4 text-white">
                  <ArrowRightIcon aria-hidden="true" />
                  <span className="text-2xl">{item}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Image */}
      <div className="min-h-64 lg:w-1/2">
        <img
          src={image}
          alt={imageAlt}
          className="h-full w-full object-cover"
        />
      </div>
    </article>
  );
}

/*
  Stacking effect (desktop), done with CSS position: sticky.
  Each card sticks a bit lower than the previous one, so the next card slides
  up over the last and only the header strip of the earlier cards stays visible.
  The browser does the positioning, so it always starts exactly when the cards
  reach the top, whatever else is pinned above on the page.
*/
export default function ServiceCards({
  services = SERVICES,
  topOffset = 40, // px from the viewport top where the first card sticks
  stepOffset = 95, // px of each earlier card left visible (its header strip)
}) {
  return (
    <section id="services" className="w-full bg-[#10161d] py-24">
      <div className="container mx-auto px-6">
        {services.map((service, i) => (
          <div
            key={i}
            style={{ top: topOffset + stepOffset * i }}
            className="mb-12 flex min-h-[440px] last:mb-0 lg:sticky motion-reduce:static"
          >
            <ServiceCard number={String(i + 1).padStart(2, "0")} {...service} />
          </div>
        ))}
      </div>
    </section>
  );
}
